
class Style():

    
    background = '#347355'
    fg_front = '#60BF81'
    font = 'arial 11'
    font_color = 'white'
    collor_button = '#223240'
    font_img = 'arial 14'