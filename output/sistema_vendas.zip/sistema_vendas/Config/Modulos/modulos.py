from tkinter import *
from tkinter import ttk
import sqlite3
from tkinter import messagebox
from datetime import date as date
from tkcalendar import Calendar, DateEntry  
import pandas as pd
from sqlite3 import Error as erro_sql
import segno as qr
import babel.numbers

